import os
from langchain.chains import RetrievalQA
from langchain_community.chat_models import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
# from langchain_fireworks import ChatFireworks
from langchain_core.language_models.chat_models import BaseChatModel
from dotenv import load_dotenv
from embedding_indexer_tourism import EmbeddingIndexerTourism

load_dotenv()

class RAGChain:
    def __init__(self, vectorstore):
        self.vectorstore = vectorstore
        self.llm = self.get_llm()

    # A function: Initiliase one of the language model
    def get_llm(self):
        if os.getenv("OPENROUTER_API_KEY"):
            print("Using DeepSeek via OpenRouter API KEY")
            return ChatOpenAI(
                openai_api_key=os.getenv("OPENROUTER_API_KEY"),
                base_url="https://openrouter.ai/api/v1",
                model_name="deepseek/deepseek-r1:free",
                temperature=0.7,
            )
        elif os.getenv("OPENAI_API_KEY"):
            print("Using OpenAI API KEY")
            return ChatOpenAI(
                openai_api_key=os.getenv("OPENAI_API_KEY"),
                model_name="gpt-3.5-turbo",
                temperature=0.7,
            )
        elif os.getenv("GEMINI_API_KEY"):
            from langchain_google_genai import ChatGoogleGenerativeAI
            return ChatGoogleGenerativeAI(
                google_api_key=os.getenv("GEMINI_API_KEY"),
                model_name="gemini-pro",
                temperature=0.7
            )
        
            # elif os.getenv("FIREWORKS_API_KEY"):
            #     return ChatFireworks(
            #         fireworks_api_key=os.getenv("FIREWORKS_API_KEY"),
            #         model_name="accounts/fireworks/models/llama-v2-7b-chat",
            #         temperature=1
            #     )
        else:
            raise ValueError("No valid API key found! Please set one in .env file.")

    def _get_prompt_template(self):
        template = (
            "You are an expert assistant for Malaysia-based queries.\n"
            "Use the following context to answer the user's question.\n\n"
            "Context:\n{context}\n\n"
            "Context:\n{context}\n\n"
            "Question:\n{question}\n\n"
            "Answer in detail:"
        )
        return PromptTemplate(template=template, input_variables=["context", "question"])

    def create_chain_tourism(self):
        # Convert the vector in a retrieval object
        retriever = self.vectorstore.as_retriever(search_kwargs={"k": 3})  # Get top 3 most relevant objects

        custom_prompt_template = """You are a specialized chatbot for Sarawak Tourism information. Your purpose is to provide accurate and helpful information about travel destinations, cultural attractions, events, accommodations, and other tourism-related topics in Sarawak, Malaysia.

        You must strictly follow these rules:
        1. Use only the information in the context below.
        2. If the answer is not in the context, simply say you don't have that information.
        3. Do not provide information outside the context.
        4. Keep your responses focused on Sarawak tourism topics, but strictly limit responses to verified information from provided context.
        5. Be professional and friendly in your responses.
        6. Make sure answers are conversational.

        Context: {context}

        Question: {question}
        Only use the context to answer. If the answer is not **directly found** in the context, do not try to guess, expand, or infer. Say: "I don't have that information."
        
        You are not required to mentioned that your answer is based on provided context or information.
        
        Answer naturally like a conversation. """
        
        # Create a prompt template object
        CUSTOM_PROMPT = PromptTemplate(
            template=custom_prompt_template,
            input_variables=["context", "question"]
        )
        
        qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",  # Merges all retrieved documents into a single LLM prompt
            retriever=retriever,  # Link the retriever from above to get relevant documents
            return_source_documents=True,  # Includes retrieved documents in the output
            chain_type_kwargs={"prompt": CUSTOM_PROMPT}  # Pass your custom prompt here
        )

        return qa_chain

    def create_chain_MM2H(self):
        # Convert the vector in a retrieval object
        retriever = self.vectorstore.as_retriever(search_kwargs={"k": 3})  # Get top 3 most relevant objects

        custom_prompt_template = """You are a specialized chatbot for Sarawak MM2H program. Your purpose is to answer questions related to visa applications, eligibility criteria, benefits, living costs, healthcare, education, and investment opportunities in Sarawak.

        You must strictly follow these rules:
        1. Only answer questions based on the provided context.
        2. If the information is not in the provided context, politely respond that you don't have that information
        3. Never provide information outside the context.
        4. Keep your responses focused on Sarawak MM2H program topics.
        5. Be friendly, professional, and helpful to potential visitors only in regard of Sarawak MM2H program topics

        Context: {context}

        Question: {question}
        Only use the context to answer. If the answer is not **directly found** in the context, do not try to guess, expand, or infer. Say: "I don’t have that information."
        Answer in a helpful and professional manner:"""

        # Create a prompt template object
        CUSTOM_PROMPT = PromptTemplate(
            template=custom_prompt_template,
            input_variables=["context", "question"]
        )
        
        qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=retriever,
            return_source_documents=True,
            chain_type_kwargs={"prompt": CUSTOM_PROMPT}
        )

        return qa_chain




################ Testing ################
if __name__ == "__main__":
    from embedding_indexer_tourism import EmbeddingIndexerTourism

    # processor = DocumentProcessor("data/bako.txt")
    # texts = processor.load_and_split()

    # indexer = EmbeddingIndexerTourism()
    # vectorstore = indexer.load_vectorstore_tourism(texts)

    # Example for Tourism chatbot
    indexer = EmbeddingIndexerTourism()
    vectorstore = indexer.load_vectorstore_tourism()
    rag = RAGChain(vectorstore)
    
    qa_chain = rag.create_chain_tourism()

    query = "where do i go in sarawak?"
    result = qa_chain.invoke({"query": query})
    print(f"Answer: {result['result']}")

