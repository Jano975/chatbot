from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import Chroma  # Replace FAISS with Chroma
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from functools import lru_cache
import os

def get_embedding_model():
    """
    Load a HuggingFace embedding model. This function can be reused across modules.
    """
    return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

class EmbeddingIndexerTourism:
    def __init__(self, persist_directory="chroma_db_tourism"):
        self.persist_directory = persist_directory
        self.embeddings = get_embedding_model()

    def load_vectorstore_tourism(self):
        """
        Load or initialize Chroma vectorstore from the specified directory.
        """
        return Chroma(
            persist_directory=self.persist_directory,
            embedding_function=self.embeddings
        )

    def create_vectorstore_tourism(self, pdf_path):
        """
        Loads a PDF, splits it into chunks, creates a vectorstore, and saves it to disk.
        """
        print(f" Loading document: {pdf_path}")
        loader = PyPDFLoader(pdf_path)
        documents = loader.load_and_split()

        print(f" Splitting into chunks...")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        texts = text_splitter.split_documents(documents)

        print(f" Saving to vectorstore at: {self.persist_directory}")
        vectorstore = Chroma.from_documents(
            documents=texts,
            embedding=self.embeddings,
            persist_directory=self.persist_directory
        )
        vectorstore.persist()
        print(" Vectorstore created and persisted.")
        return vectorstore
    


################ Testing ################
if __name__ == "__main__":
    print(" Testing EmbeddingIndexerTourism...")

    test_pdf_path = "uploads/sample.pdf"
    if not os.path.exists(test_pdf_path):
        print(f" Test file not found: {test_pdf_path}")
    else:
        indexer = EmbeddingIndexerTourism()
        indexer.create_vectorstore_tourism(test_pdf_path)

        # Reload the vectorstore
        vs = indexer.load_vectorstore_tourism()
        print(f" Vectorstore loaded with {len(vs.get()['ids'])} documents")