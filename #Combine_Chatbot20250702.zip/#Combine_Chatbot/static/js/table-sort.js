document.addEventListener("DOMContentLoaded", function () {
  const headers = document.querySelectorAll("th.sortable");

  headers.forEach((header, index) => {
    header.addEventListener("click", () => {
      const table = header.closest("table");
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      const ascending = header.classList.toggle("asc");

      // Remove 'asc' class from other headers
      headers.forEach((h, i) => {
        if (i !== index) h.classList.remove("asc");
      });

      rows.sort((a, b) => {
        const cellA = a.children[index].textContent.trim();
        const cellB = b.children[index].textContent.trim();

        const isNumeric = !isNaN(cellA) && !isNaN(cellB);
        if (isNumeric) {
          return ascending ? cellA - cellB : cellB - cellA;
        } else {
          return ascending
            ? cellA.localeCompare(cellB)
            : cellB.localeCompare(cellA);
        }
      });

      const tbody = table.querySelector("tbody");
      tbody.innerHTML = "";
      rows.forEach(row => tbody.appendChild(row));
    });
  });
});
