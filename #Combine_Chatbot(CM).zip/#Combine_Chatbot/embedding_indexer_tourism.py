from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import PyPDFLoader, WebBaseLoader
from langchain_community.vectorstores import Chroma  # Replace FAISS with Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os

def get_embedding_model():
    return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

class EmbeddingIndexerTourism:
    def __init__(self, persist_directory="chroma_db_tourism"):
        self.persist_directory = persist_directory
        self.embeddings = get_embedding_model()

    def load_vectorstore_tourism(self):
        """Load an existing vectorstore from disk."""
        return Chroma(
            persist_directory=self.persist_directory,
            embedding_function=self.embeddings
        )

    def create_vectorstore_tourism(self, path, is_url=False):
        """
        Load a PDF or a URL, split into chunks, create a vectorstore, and save to disk.
        """
        if not is_url and (path.lower().startswith("http://") or path.lower().startswith("https://")):
            is_url = True
        if is_url:
            loader = WebBaseLoader(path)
        else:
            loader = PyPDFLoader(path)

        documents = loader.load_and_split()
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        texts = text_splitter.split_documents(documents)

        vectorstore = Chroma.from_documents(
            documents=texts,
            embedding=self.embeddings,
            persist_directory=self.persist_directory
        )
        vectorstore.persist()
        return vectorstore
    
    def remove_file_from_index(self, filename):
        db = Chroma(persist_directory=self.persist_directory)
        ids = [doc.metadata["source"] for doc in db.get()["documents"] if doc.metadata.get("source") == filename]
        if ids:
            db.delete(ids)

################ Testing ################
if __name__ == "__main__":
    print(" Testing EmbeddingIndexerTourism...")

    test_pdf_path = "uploads/sample.pdf"
    if os.path.exists(test_pdf_path):
        indexer = EmbeddingIndexerTourism()
        indexer.create_vectorstore_tourism(test_pdf_path)
        vs = indexer.load_vectorstore_tourism()
        print(f"Vectorstore loaded with {len(vs.get()['ids'])} documents")
    else:
        print(f"PDF test file not found: {test_pdf_path}")

    # Reload the vectorstore
    test_url = "https://en.wikipedia.org/wiki/Sarawak"
    indexer = EmbeddingIndexerTourism()
    indexer.create_vectorstore_tourism(test_url, is_url=True)