from dotenv import load_dotenv
load_dotenv()

from flask import Flask, render_template, request, jsonify, send_file, send_from_directory, flash, redirect, session, redirect,url_for
from document_processor import DocumentProcessor
from embedding_indexer_tourism import EmbeddingIndexerTourism
from embedding_indexer_mm2h import EmbeddingIndexerMM2H
from rag_chain import RAGChain
from chatbot import Chatbot, create_chatbot_for_module
from chatbot_performance import log_chatbot_usage, load_chat_logs, calculate_avg_response
from werkzeug.utils import secure_filename
import time
import json
import os
import sqlite3
import mimetypes
import shutil

app = Flask(__name__)
app.secret_key = "your_secret_key"

chatbot_tourism = None
chatbot_mm2h = None
CONFIG_FILE = "current_model.json"

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "model_type": "OpenAI",
        "model_name": "gpt-4.1-nano",
        "api_key": "",
        "LANGCHAIN_CONFIG": {
            "retriever": {
                "tourism": {"vector_store_path": "chroma_db_tourism"},
                "mm2h": {"vector_store_path": "chroma_db_MM2H"}
            }
        }
    }

def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

def reload_chatbots():
    global chatbot_tourism, chatbot_mm2h, config
    chatbot_tourism = create_chatbot_for_module("tourism", config)
    chatbot_mm2h = create_chatbot_for_module("mm2h", config)

config = load_config()
reload_chatbots()

def get_db_connection():
    conn = sqlite3.connect('data/users.db')
    conn.row_factory = sqlite3.Row
    return conn

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

UPLOAD_FOLDER = config.get("UPLOAD_FOLDER", "uploads")
ALLOWED_EXTENSIONS = set(config.get("ALLOWED_EXTENSIONS", ["pdf"]))

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'your_secret_key'



# Initialize once when app starts
indexer_tourism = EmbeddingIndexerTourism(persist_directory=config["LANGCHAIN_CONFIG"]["retriever"]["tourism"]["vector_store_path"])
vectorstore_tourism = indexer_tourism.load_vectorstore_tourism()
rag_chain_tourism = RAGChain(vectorstore_tourism)
chatbot_tourism = create_chatbot_for_module("tourism", config)

indexer_mm2h = EmbeddingIndexerMM2H(persist_directory=config["LANGCHAIN_CONFIG"]["retriever"]["mm2h"]["vector_store_path"])
vectorstore_mm2h = indexer_mm2h.load_vectorstore_MM2H()
rag_chain_mm2h = RAGChain(vectorstore_mm2h)
chatbot_mm2h = create_chatbot_for_module("mm2h", config)


# Global variable to store the chatbot instance
current_chatbot = None

# Chatbot Tourism
@app.route("/chatbot1", methods=["GET", "POST"])
def chatbot1():
    if request.method == "POST":
        data = request.get_json()
        query = data.get("message", "").strip()
        if not query:
            return jsonify({"error": "Query cannot be empty."})
        with open("current_model.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        bot = create_chatbot_for_module("tourism", config)
        try:
            response = bot.get_response(query)
            return jsonify({"response": response})
        except Exception as e:
            return jsonify({"error": str(e)})
    return render_template("chatbot1.html")

# Chatbot MM2H
@app.route("/chatbot2", methods=["GET", "POST"])
def chatbot2():
    if request.method == "POST":
        data = request.get_json()
        query = data.get("message", "").strip()
        if not query:
            return jsonify({"error": "Query cannot be empty."})
        with open("current_model.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        bot = create_chatbot_for_module("mm2h", config)
        try:
            response = bot.get_response(query)
            return jsonify({"response": response})
        except Exception as e:
            return jsonify({"error": str(e)})
    return render_template("chatbot2.html")

# Home routes
@app.route('/')
def home():
    return render_template('home.html')

# Index route
@app.route('/index')
def index():
    return render_template('index.html')

# Admin Dashboard
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        flash("Please login first!", "danger")
        return redirect(url_for('login'))
    return render_template('dashboard.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = get_db_connection()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            (username, password)
        ).fetchone()
        conn.close()

        if user:
            session['user'] = user['username']
            flash("Login successful", "success")
            return redirect(url_for('dashboard')) 
        else:
            error = "Invalid username or password"

    return render_template('login.html', error=error)

# Logout route
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('home')) 

# File upload route
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    full_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if os.path.exists(full_path):
        import mimetypes
        mimetype = mimetypes.guess_type(full_path)[0]
        return send_file(full_path, mimetype=mimetype)
    else:
        return f"File not found: {filename}", 404

def view_uploaded_file(module, filename):
    # Check if the module directory exists
    module_dir = os.path.join(app.config['UPLOAD_FOLDER'], module)
    if os.path.exists(module_dir):
        return send_from_directory(module_dir, filename)
    else:
        return f"Module not found: {module}", 404

# Admin Manage Database route
@app.route('/admin/manage-db', methods=['GET', 'POST'])
def manage_database():
    UPLOAD_FOLDER = app.config['UPLOAD_FOLDER']
    selected_module = request.form.get('module') or request.args.get('module') or 'tourism'
    filter_module = request.args.get('filter_module', 'all')
    error_message = None

    if request.method == 'POST':
        upload_modules = request.form.getlist('upload_module')  # Which modules to sync

        # 1. Upload PDF file
        if 'upload' in request.form and 'file' in request.files:
            uploaded_file = request.files['file']
            filename = secure_filename(uploaded_file.filename)
            ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
            if not filename or ext != "pdf":
                error_message = "Only PDF files are allowed."
            else:
                for module in upload_modules:
                    save_path = os.path.join(UPLOAD_FOLDER, module)
                    os.makedirs(save_path, exist_ok=True)
                    full_path = os.path.join(save_path, filename)
                    uploaded_file.seek(0)
                    uploaded_file.save(full_path)
                    # Call embedding indexer
                    try:
                        if module == "tourism":
                            from embedding_indexer_tourism import EmbeddingIndexerTourism
                            EmbeddingIndexerTourism().create_vectorstore_tourism(full_path)
                        elif module == "mm2h":
                            from embedding_indexer_mm2h import EmbeddingIndexerMM2H
                            EmbeddingIndexerMM2H().create_vectorstore_MM2H(full_path)
                    except Exception as e:
                        error_message = f"Error indexing PDF: {str(e)}"
            return redirect(url_for('manage_database', module=selected_module, filter_module=filter_module))

        # 2. Upload web link
        if 'upload_link' in request.form:
            web_link = request.form.get('web_link', '').strip()
            if not web_link:
                error_message = "Web link cannot be empty."
            elif not (web_link.startswith("http://") or web_link.startswith("https://")):
                error_message = "Invalid URL, must start with http:// or https://"
            else:
                try:
                    for module in upload_modules:
                        if module == "tourism":
                            from embedding_indexer_tourism import EmbeddingIndexerTourism
                            EmbeddingIndexerTourism().create_vectorstore_tourism(web_link, is_url=True)
                        elif module == "mm2h":
                            from embedding_indexer_mm2h import EmbeddingIndexerMM2H
                            EmbeddingIndexerMM2H().create_vectorstore_MM2H(web_link, is_url=True)
                except Exception as e:
                    error_message = f"Error indexing URL: {str(e)}"
            return redirect(url_for('manage_database', module=selected_module, filter_module=filter_module))

        # 3. Delete file
        if 'delete' in request.form:
            delete_info = request.form['delete']  # "module/filename"
            module, filename = delete_info.split('/', 1)
            delete_path = os.path.join(app.config['UPLOAD_FOLDER'], module, filename)
            try:
                if os.path.exists(delete_path):
                    os.remove(delete_path)
                # Delete from vectorstore
                try:
                    if module == "tourism":
                        from embedding_indexer_tourism import EmbeddingIndexerTourism
                        EmbeddingIndexerTourism().remove_file_from_index(filename)
                    elif module == "mm2h":
                        from embedding_indexer_mm2h import EmbeddingIndexerMM2H
                        EmbeddingIndexerMM2H().remove_file_from_index(filename)
                except Exception as e:
                    print(f"Delete from chroma failed: {e}")
                flash(f"Deleted file: {filename}")
            except Exception as e:
                flash(f"File not found or error: {filename}, {e}")
            return redirect(url_for('manage_database', module=selected_module, filter_module='all'))

    uploaded_files = {}
    for module_name in os.listdir(UPLOAD_FOLDER):
        module_path = os.path.join(UPLOAD_FOLDER, module_name)
        if os.path.isdir(module_path):
            uploaded_files[module_name] = os.listdir(module_path)

    if filter_module == 'all':
        filtered_files = uploaded_files
    else:
        filtered_files = {filter_module: uploaded_files.get(filter_module, [])}

    return render_template(
        'admin_manage_database.html',
        modules=["tourism", "mm2h"],
        selected_module=selected_module,
        filter_module=filter_module,
        uploaded_files=filtered_files,
        error=error_message
    )

# View route
@app.route('/view_uploaded_file/<module>/<filename>')
def view_uploaded_file(module, filename):
    module_dir = os.path.join(app.config['UPLOAD_FOLDER'], module)
    return send_from_directory(module_dir, filename)

# Monitor route
@app.route("/monitor")
def monitor():
    if 'user' not in session:
        flash("Please login first!", "danger")
        return redirect(url_for('login'))
    logs = load_chat_logs()  
    total_calls = len(logs)
    avg_response = calculate_avg_response(logs)  
    return render_template("monitor.html", logs=logs, total_calls=total_calls, avg_response=avg_response)

# Change module route
@app.route('/change_model', methods=['GET', 'POST'])
def change_model_page():
    global config
    openai_key = os.environ.get("OPENAI_API_KEY", "")
    openrouter_key = os.environ.get("OPENROUTER_API_KEY", "")
    fireworks_key = os.environ.get("FIREWORKS_API_KEY", "")
    gemini_key = os.environ.get("GEMINI_API_KEY", "")

    if request.method == 'POST':
        model_type = request.form.get("model_type")
        model_name = request.form.get("model_name")
        api_key = request.form.get("api_key")
        if not (model_type and model_name and api_key):
            flash("All fields are required.", "danger")
        else:
            try:
                config["model_type"] = model_type
                config["model_name"] = model_name
                config["api_key"] = api_key
                save_config(config)
                reload_chatbots()
                flash(f"Model updated and reloaded successfully. Now using: {model_type} ({model_name})", "success")
                return redirect(url_for('change_model_page'))
            except Exception as e:
                flash(f"Failed to update: {str(e)}", "danger")

    return render_template(
        "change_model.html",
        model_type=config.get("model_type", ""),
        model_name=config.get("model_name", ""),
        api_key=config.get("api_key", ""),
        openai_key=openai_key,
        openrouter_key=openrouter_key,
        fireworks_key=fireworks_key,
        gemini_key=gemini_key,
    )

@app.route("/reload_model", methods=["POST"])
def reload_model():
    global chatbot_tourism, chatbot_mm2h
    try:
        chatbot_tourism = create_chatbot_for_module("tourism", config)
        chatbot_mm2h = create_chatbot_for_module("mm2h", config)
        print("[INFO] Models reloaded successfully.")
        return jsonify({"status": "success", "message": "Models reloaded successfully"})
    except Exception as e:
        print("[ERROR] Model reload failed:", e)
        return jsonify({"status": "error", "message": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
