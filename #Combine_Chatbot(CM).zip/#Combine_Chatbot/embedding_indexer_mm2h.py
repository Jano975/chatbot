from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma  # Replace FAISS with Chroma
from langchain_community.document_loaders import PyPDFLoader, WebBaseLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os

def get_embedding_model():
    """Load HuggingFace embedding model."""
    return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

class EmbeddingIndexerMM2H:
    def __init__(self, persist_directory="chroma_db_MM2H"):
        self.persist_directory = persist_directory
        self.embeddings = get_embedding_model()

    def load_vectorstore_MM2H(self):
        """Load Chroma vectorstore from disk."""
        return Chroma(
            persist_directory=self.persist_directory,
            embedding_function=self.embeddings
        )

    def create_vectorstore_MM2H(self, path, is_url=False):
        """
        Create and save vectorstore from PDF or webpage.
        """
        if not is_url and (path.lower().startswith("http://") or path.lower().startswith("https://")):
            is_url = True
        if is_url:
            loader = WebBaseLoader(path)
        else:
            loader = PyPDFLoader(path)

        documents = loader.load_and_split()
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        texts = text_splitter.split_documents(documents)

        vectorstore = Chroma.from_documents(
            documents=texts,
            embedding=self.embeddings,
            persist_directory=self.persist_directory
        )
        vectorstore.persist()
        return vectorstore
    
    def remove_file_from_index(self, filename):
        db = Chroma(persist_directory=self.persist_directory)
        ids = [doc.metadata["source"] for doc in db.get()["documents"] if doc.metadata.get("source") == filename]
        if ids:
            db.delete(ids)

################ Testing ################
if __name__ == "__main__":
    print(" Testing EmbeddingIndexerMM2H...")

    # Test with a sample PDF file
    test_pdf_path = "uploads/sample.pdf"
    if os.path.exists(test_pdf_path):
        indexer = EmbeddingIndexerMM2H()
        indexer.create_vectorstore_MM2H(test_pdf_path)
        vs = indexer.load_vectorstore_MM2H()
        print(f"Vectorstore loaded with {len(vs.get()['ids'])} documents")
    else:
        print(f"PDF test file not found: {test_pdf_path}")

    # Test with a sample URL
    test_url = "https://en.wikipedia.org/wiki/Sarawak"
    indexer = EmbeddingIndexerMM2H()
    indexer.create_vectorstore_MM2H(test_url, is_url=True)