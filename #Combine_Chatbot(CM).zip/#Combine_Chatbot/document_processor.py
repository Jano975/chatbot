from langchain_community.document_loaders import UnstructuredPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
import os


class DocumentProcessor:
    def __init__(self, chunk_size=1000, chunk_overlap=200):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap
        )
        self.embedding = OpenAIEmbeddings()

def process(self, file_path, vectorstore):
    from langchain_community.document_loaders import PyPDFLoader
    from langchain_text_splitters import RecursiveCharacterTextSplitter

    # Load PDF
    loader = PyPDFLoader(file_path)
    documents = loader.load()
    
    if not documents:
        raise ValueError("No documents were loaded from the PDF. It may be empty or unreadable.")
    
    # Split text into chunks
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    docs = text_splitter.split_documents(documents)
    
    if not docs:
        raise ValueError("Document splitting returned no chunks. Check if the PDF contains readable text.")

    # Add to vectorstore
    vectorstore.add_documents(docs)


# ------------   TESTING  -----------------
if __name__ == "__main__":
    from embedding_indexer_tourism import EmbeddingIndexerTourism

    indexer = EmbeddingIndexerTourism()
    vs = indexer.load_vectorstore_tourism()
    
    processor = DocumentProcessor()
    test_pdf_path = "uploads/sample.pdf"  # Replace with a real PDF path
    if os.path.exists(test_pdf_path):
        processor.process(test_pdf_path, vs)
    else:
        print("Test PDF file not found.")
