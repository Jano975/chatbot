import os
import json
from dotenv import load_dotenv
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.language_models.chat_models import BaseChatModel
from embedding_indexer_tourism import EmbeddingIndexerTourism
from embedding_indexer_mm2h import EmbeddingIndexerMM2H
from rag_chain import RAGChain

load_dotenv()

class Chatbot:
    def __init__(self, chain, model_type, model_name):
        self.chain = chain
        self.model_type = model_type
        self.model_name = model_name

    def get_response(self, query):
        if query.strip().lower() in ["what model you are", "你是什么模型"]:
            return f"I am {self.model_type} ({self.model_name})"
        try:
            response = self.chain.invoke({"query": query})
            return response["result"]
        except Exception as e:
            return f"Error: {str(e)}"


def create_chatbot_for_module(module, config=None):
    """
    Create a Chatbot instance for the specified module using current config.
    """
    if config is None:
        with open("current_model.json", "r", encoding="utf-8") as f:
            config = json.load(f)
    if module == "tourism":
        path = config["LANGCHAIN_CONFIG"]["retriever"]["tourism"]["vector_store_path"]
        indexer = EmbeddingIndexerTourism(persist_directory=path)
        vectorstore = indexer.load_vectorstore_tourism()
        chain = RAGChain(vectorstore)
        chain = chain.create_chain_tourism()
    elif module == "mm2h":
        path = config["LANGCHAIN_CONFIG"]["retriever"]["mm2h"]["vector_store_path"]
        indexer = EmbeddingIndexerMM2H(persist_directory=path)
        vectorstore = indexer.load_vectorstore_MM2H()
        chain = RAGChain(vectorstore)
        chain = chain.create_chain_MM2H()
    else:
        raise ValueError("Unknown module")
    model_type = config.get("model_type", "OpenAI")
    model_name = config.get("model_name", "gpt-4.1-nano")
    return Chatbot(chain, model_type, model_name)

def get_llm(model_name: str, provider: str) -> BaseChatModel:
    if provider == "openai":
        return ChatOpenAI(
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            model_name=model_name
        )
    # elif provider == "fireworks":
    #     return ChatFireworks(
    #         api_key=os.getenv("FIREWORKS_API_KEY"),
    #         model=model_name
    #     )
    elif provider == "gemini":
        return ChatGoogleGenerativeAI(
            google_api_key=os.getenv("GOOGLE_API_KEY"),
            model=model_name
        )
    else:
        raise ValueError("Unsupported provider. Please check your config.")


# ===========   TESTING    ==========
if __name__ == "__main__":
    from embedding_indexer_tourism import EmbeddingIndexerTourism
    from rag_chain import RAGChain

    # Load configuration
    with open("chatbot_config.json", "r", encoding="utf-8") as f:
        config = json.load(f)

    # Load Tourism chatbot
    tourism_path = config["LANGCHAIN_CONFIG"]["retriever"]["tourism"]["vector_store_path"]
    tourism_indexer = EmbeddingIndexerTourism(persist_directory=tourism_path)
    tourism_vs = tourism_indexer.load_vectorstore_tourism()
    
    rag = RAGChain(tourism_vs)
    chain = rag.create_chain_tourism()
    bot = Chatbot(chain)

    query = "Tell me about Kuching food"
    print("Testing Tourism Chatbot:")
    print("Query:", query)
    print("Response:", bot.get_response(query))