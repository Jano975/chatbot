import os
import json
from datetime import datetime
import logging

# === Logging configuration ===
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# === Constants ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(BASE_DIR, "chatbot_log.json")


# === Utility Functions ===
def load_chat_logs(log_file_path="chatbot_log.json"):
    """
    Loads all chatbot interaction logs from a JSON file.
    """
    if not os.path.exists(log_file_path):
        return []

    with open(log_file_path, "r", encoding="utf-8") as file:
        logs = json.load(file)

    return logs

def calculate_avg_response(logs):
    """
    Calculates the average response time from logs.
    """
    if not logs:
        return 0.0

    total_time = sum(log.get("response_time", 0) for log in logs)
    return round(total_time / len(logs), 2)


def _save_logs(logs):
    """Save log entries to file"""
    try:
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=4, ensure_ascii=False)
    except Exception as e:
        logging.error(f"Error saving log file: {e}")


# === Core Functions ===
def log_chatbot_usage(module, response_time_ms, user_id=None, question_text=None, response_text=None):
    """
    Log each chatbot interaction to a JSON file.

    :param module: Module name, e.g., "Tourism" or "MM2H"
    :param response_time_ms: Response time in milliseconds
    :param user_id: Optional, user identifier
    :param question_text: Optional, the original user input
    :param response_text: Optional, the chatbot response
    """
    logs = load_chat_logs()

    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "module": module,
        "response_time_ms": response_time_ms
    }

    if user_id:
        log_entry["user_id"] = user_id
    if question_text:
        log_entry["question"] = question_text
    if response_text:
        log_entry["response"] = response_text

    logs.append(log_entry)
    _save_logs(logs)

    logging.info(f"Logged chatbot usage: {log_entry}")


def get_summary():
    """
    Generate a summary of chatbot interactions.

    :return: logs, total_calls, avg_response_time
    """
    logs = load_chat_logs()
    total_calls = len(logs)
    avg_response_time = 0

    if total_calls > 0:
        total_response_time = sum(log.get("response_time_ms", 0) for log in logs)
        avg_response_time = total_response_time / total_calls

    return logs, total_calls, round(avg_response_time, 2)

__all__ = ["log_chatbot_usage", "load_chat_logs", "calculate_avg_response", "get_summary"]

