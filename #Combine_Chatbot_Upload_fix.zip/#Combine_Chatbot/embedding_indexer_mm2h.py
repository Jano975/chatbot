from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma  # Replace FAISS with Chroma
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from functools import lru_cache
import os

def get_embedding_model():
    """
    Load HuggingFace embedding model.
    """
    return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

class EmbeddingIndexerMM2H:
    def __init__(self, persist_directory="chroma_db_MM2H"):
        self.persist_directory = persist_directory
        self.embeddings = get_embedding_model()

    def load_vectorstore_MM2H(self):
        """
        Load Chroma vectorstore from disk.
        """
        return Chroma(
            persist_directory=self.persist_directory,
            embedding_function=self.embeddings
        )

    def create_vectorstore_MM2H(self, pdf_path):
        """
        Create and save vectorstore from PDF.
        """
        print(f" Loading document: {pdf_path}")
        loader = PyPDFLoader(pdf_path)
        documents = loader.load_and_split()

        print(" Splitting into chunks...")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        texts = text_splitter.split_documents(documents)

        print(f" Creating vectorstore at: {self.persist_directory}")
        vectorstore = Chroma.from_documents(
            documents=texts,
            embedding=self.embeddings,
            persist_directory=self.persist_directory
        )
        vectorstore.persist()
        print(" Vectorstore created and saved.")
        return vectorstore

################ Testing ################
if __name__ == "__main__":
    print(" Testing EmbeddingIndexerMM2H...")

    test_pdf_path = "uploads/sample_mm2h.pdf"
    if not os.path.exists(test_pdf_path):
        print(f" Test file not found: {test_pdf_path}")
    else:
        indexer = EmbeddingIndexerMM2H()
        indexer.create_vectorstore_MM2H(test_pdf_path)

        vs = indexer.load_vectorstore_MM2H()
        print(f" Vectorstore loaded with {len(vs.get()['ids'])} documents.")