import os
import json
from dotenv import load_dotenv
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_fireworks import ChatFireworks
from langchain_core.language_models.chat_models import BaseChatModel

load_dotenv()

class Chatbot:
    def __init__(self, chain: RetrievalQA):
        self.chain = chain

    def get_response(self, query: str) -> str:
        try:
            response = self.chain.invoke({"query": query})
            return response["result"]
        except Exception as e:
            return f"Error: {str(e)}"


def get_llm(model_name: str, provider: str) -> BaseChatModel:
    if provider == "openai":
        return ChatOpenAI(
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            model_name=model_name
        )
    elif provider == "fireworks":
        return ChatFireworks(
            api_key=os.getenv("FIREWORKS_API_KEY"),
            model=model_name
        )
    elif provider == "gemini":
        return ChatGoogleGenerativeAI(
            google_api_key=os.getenv("GOOGLE_API_KEY"),
            model=model_name
        )
    else:
        raise ValueError("Unsupported provider. Please check your config.")


# ===========   TESTING    ==========
if __name__ == "__main__":
    from embedding_indexer_tourism import EmbeddingIndexerTourism
    from rag_chain import RAGChain

    # Load configuration
    with open("chatbot_config.json", "r", encoding="utf-8") as f:
        config = json.load(f)

    # Load Tourism chatbot
    tourism_path = config["LANGCHAIN_CONFIG"]["retriever"]["tourism"]["vector_store_path"]
    tourism_indexer = EmbeddingIndexerTourism(persist_directory=tourism_path)
    tourism_vs = tourism_indexer.load_vectorstore_tourism()
    
    rag = RAGChain(tourism_vs)
    chain = rag.create_chain_tourism()
    bot = Chatbot(chain)

    query = "Tell me about Kuching food"
    print("Testing Tourism Chatbot:")
    print("Query:", query)
    print("Response:", bot.get_response(query))