from flask import Flask, render_template, request, jsonify, send_from_directory, flash, redirect, session, redirect,url_for
from document_processor import DocumentProcessor
from embedding_indexer_tourism import EmbeddingIndexerTourism
from embedding_indexer_mm2h import EmbeddingIndexerMM2H
from rag_chain import RAGChain
from chatbot import Chatbot
from chatbot_performance import log_chatbot_usage, load_chat_logs, calculate_avg_response
from werkzeug.utils import secure_filename
from chatbot_performance import log_chatbot_usage, load_chat_logs, calculate_avg_response
import time
import json
import os
import sqlite3

def get_db_connection():
    conn = sqlite3.connect('data/users.db')
    conn.row_factory = sqlite3.Row
    return conn

def create_chatbot_for_module(module_key: str):
    retriever_config = config["LANGCHAIN_CONFIG"]["retriever"][module_key]
    vector_path = retriever_config["vector_store_path"]
    
    if module_key == "tourism":
        indexer = EmbeddingIndexerTourism(persist_directory=vector_path)
        vectorstore = indexer.load_vectorstore_tourism()
        chain = RAGChain(vectorstore).create_chain_tourism()
    elif module_key == "mm2h":
        indexer = EmbeddingIndexerMM2H(persist_directory=vector_path)
        vectorstore = indexer.load_vectorstore_MM2H()
        chain = RAGChain(vectorstore).create_chain_MM2H()
    else:
        raise ValueError("Unsupported module key.")

    return Chatbot(chain)

# === Load config ===
with open("chatbot_config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

app = Flask(__name__)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'pdf', 'txt'}

# Initialize once when app starts
indexer_tourism = EmbeddingIndexerTourism(persist_directory=config["LANGCHAIN_CONFIG"]["retriever"]["tourism"]["vector_store_path"])
vectorstore_tourism = indexer_tourism.load_vectorstore_tourism()
rag_chain_tourism = RAGChain(vectorstore_tourism)
chatbot_tourism = create_chatbot_for_module("tourism")

indexer_mm2h = EmbeddingIndexerMM2H(persist_directory=config["LANGCHAIN_CONFIG"]["retriever"]["mm2h"]["vector_store_path"])
vectorstore_mm2h = indexer_mm2h.load_vectorstore_MM2H()
rag_chain_mm2h = RAGChain(vectorstore_mm2h)
chatbot_mm2h = create_chatbot_for_module("mm2h")


# Global variable to store the chatbot instance
current_chatbot = None

# Chatbot Tourism
@app.route('/chatbot1')
def chatbot1():
    return render_template('chatbot1.html')

# Chatbot MM2H
@app.route('/chatbot2')
def chatbot2():
    return render_template('chatbot2.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = get_db_connection()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            (username, password)
        ).fetchone()
        conn.close()

        if user:
            session['user'] = user['username']
            flash("Login successful", "success")
            return redirect(url_for('dashboard')) 
        else:
            error = "Invalid username or password"

    return render_template('login.html', error=error)

app.secret_key = 'your-secret-key'

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('home'))


# Chatbot Tourism
@app.route('/chatbot1', methods=['POST'])
def chat_tourism():
    user_input = request.json.get("message")
    if not user_input:
        return jsonify({"response": "No input provided."})
    start = time.time()
    response = chatbot_tourism.get_response(user_input)
    end = time.time()
    log_chatbot_usage(
        module="Tourism",
        response_time_ms=int((end - start) * 1000),
        user_id="guest",
        question_text=user_input,
        response_text=response
    )

    return jsonify({"response": response})


# Chatbot MM2H
@app.route('/chatbot2', methods=['POST'])
def chat_mm2h():
    user_input = request.json.get("message")
    if not user_input:
        return jsonify({"response": "No input provided."})
    start = time.time()
    response = chatbot_mm2h.get_response(user_input)
    end = time.time()
    log_chatbot_usage(
        module="MM2H",
        response_time_ms=int((end - start) * 1000),
        user_id="guest",
        question_text=user_input,
        response_text=response
    )

    return jsonify({"response": response})

# Admin---> Upload/Delete files
UPLOAD_FOLDER = config.get("UPLOAD_FOLDER", "uploads")
ALLOWED_EXTENSIONS = set(config.get("ALLOWED_EXTENSIONS", ["txt", "pdf", "png", "jpg", "jpeg", "gif"]))

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = "secret_key_for_flashing_messages"

@app.route('/admin/manage-db', methods=['GET', 'POST'])
def manage_database():
    if request.method == 'POST':
        # --- Handle file deletion ---
        if 'delete' in request.form:
            filename = request.form['delete']
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if os.path.exists(filepath):
                os.remove(filepath)
                flash(f"Deleted file: {filename}", "success")
            else:
                flash(f"File not found: {filename}", "danger")
            return redirect(url_for('manage_database'))

        # --- Handle file upload ---
        uploaded_file = request.files.get('file')
        if uploaded_file and allowed_file(uploaded_file.filename):
            filename = secure_filename(uploaded_file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            uploaded_file.save(filepath)

            # Process and index
            try:
                docs = DocumentProcessor(filepath).load()
                if docs:
                    vectorstore_tourism.add_documents(docs)
                    flash(f"Uploaded and indexed: {filename}", "success")
                else:
                    flash(f"Uploaded: {filename}, but no text extracted.", "warning")
            except Exception as e:
                flash(f"Error processing file {filename}: {str(e)}", "danger")
        else:
            flash("Invalid file type. Only PDF and TXT files are supported.", "danger")

        return redirect(url_for('manage_database'))

    # --- Render file list ---
    try:
        file_list = os.listdir(app.config['UPLOAD_FOLDER'])
    except FileNotFoundError:
        file_list = []
        flash("Upload folder not found!", "danger")

    return render_template('admin_manage_database.html', files=file_list)

# Uploaded files route
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Monitor route
@app.route("/monitor")
def monitor():
    logs = load_chat_logs()  
    total_calls = len(logs)
    avg_response = calculate_avg_response(logs)  
    return render_template("monitor.html", logs=logs, total_calls=total_calls, avg_response=avg_response)

# Change module route
@app.route('/change_model', methods=['GET', 'POST'])
def change_model_page():
    global chatbot_tourism, chatbot_mm2h, config

    if request.method == 'POST':
        model_type = request.form.get("model_type")
        model_name = request.form.get("model_name")
        api_key = request.form.get("api_key")

        if not (model_type and model_name and api_key):
            flash("All fields are required.", "danger")
        else:
            try:
                # Update in-memory config object
                config["LANGCHAIN_CONFIG"]["llm"]["type"] = model_type
                config["LANGCHAIN_CONFIG"]["llm"]["model_name"] = model_name
                config["LANGCHAIN_CONFIG"]["llm"]["api_key"] = api_key

                # Write updated config to JSON file
                with open("chatbot_config.json", "w", encoding="utf-8") as f:
                    json.dump(config, f, indent=2)

                # Reload both chatbots
                chatbot_tourism = create_chatbot_for_module("tourism")
                chatbot_mm2h = create_chatbot_for_module("mm2h")

                flash("Model updated and reloaded successfully.", "success")
            except Exception as e:
                flash(f"Failed to update: {str(e)}", "danger")

    # GET or after POST: pass current config to form
    llm_config = config.get("LANGCHAIN_CONFIG", {}).get("llm", {})
    
    return render_template(
        "change_model.html",
        model_type=llm_config.get("type", ""),
        model_name=llm_config.get("model_name", ""),
        api_key=llm_config.get("api_key", ""),
        openai_key=os.getenv("OPENAI_API_KEY", ""),
        gemini_key=os.getenv("GEMINI_API_KEY", ""),
        fireworks_key=os.getenv("FIREWORKS_API_KEY", ""),
        deepseek_key=os.getenv("DEEPSEEK_API_KEY", "")
    )

@app.route("/reload_model", methods=["POST"])
def reload_model():
    global chatbot_tourism, chatbot_mm2h
    try:
        chatbot_tourism = create_chatbot_for_module("tourism")
        chatbot_mm2h = create_chatbot_for_module("mm2h")
        print("[INFO] Models reloaded successfully.")
        return jsonify({"status": "success", "message": "Models reloaded successfully"})
    except Exception as e:
        print("[ERROR] Model reload failed:", e)
        return jsonify({"status": "error", "message": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
